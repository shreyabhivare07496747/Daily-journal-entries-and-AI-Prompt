/* =========================================================
   Daily Journal with AI Writing Prompts - Netlify App Script
   ========================================================= */

const STORAGE_KEY = "daily_journal_ai_entries";

const PROMPT_BANK = {
  Happy: [
    "What made you feel genuinely happy today while thinking about {topic}?",
    "How did today's experience with {topic} bring joy to your day?",
    "What is something about {topic} you want to remember and celebrate?",
    "Who shared a positive or uplifting moment with you today regarding {topic}?"
  ],
  Sad: [
    "What happened today that affected your feelings about {topic}, and what did you learn?",
    "What felt difficult today regarding {topic}, and how can you show kindness to yourself?",
    "What comfort or reassurance do you need most right now concerning {topic}?",
    "Write about one small thing that gave you hope despite how hard {topic} felt today."
  ],
  Calm: [
    "Describe a peaceful moment you experienced today related to {topic}.",
    "What brought a sense of balance and calm to your mind while reflecting on {topic}?",
    "What are you grateful to accept exactly as it is right now regarding {topic}?",
    "How can you nurture your peace of mind regarding {topic} tomorrow?"
  ],
  Excited: [
    "What are you most excited about regarding {topic}, and why?",
    "What dreams, milestones, or opportunities are opening up around {topic}?",
    "Describe the enthusiasm and energy you felt today when thinking about {topic}.",
    "What is the next creative or bold step you want to take with {topic}?"
  ],
  Stressed: [
    "What caused stress around {topic}, and what could help you handle it better?",
    "What is one small thing within your control that could lighten your burden with {topic}?",
    "What would happen if you paused and gave yourself permission to rest from {topic}?",
    "What gentle reminder do you need to hear about managing your expectations on {topic}?"
  ],
  Angry: [
    "What situation involving {topic} made you angry, and how could you respond constructively?",
    "What underlying feelings (like frustration, hurt, or feeling unheard) were triggered by {topic}?",
    "How can you establish clearer boundaries or communicate your needs regarding {topic}?",
    "What does healthy release or constructive action on {topic} look like for you?"
  ],
  Grateful: [
    "What are three things about {topic} that you are grateful for today?",
    "Who contributed positively to your experience with {topic} today, and how?",
    "What is an unexpected blessing or pleasant surprise connected to {topic}?",
    "How has your experience with {topic} helped you grow as a person?"
  ]
};

// State
let entries = [];
let activeSearch = "";
let activeDateFilter = "";
let currentPrompt = "";

// Initial seed data if first time
const SEED_ENTRIES = [
  {
    id: 1,
    entry_date: new Date().toISOString().split("T")[0],
    mood: "Excited",
    topic: "Building Web Apps",
    title: "Deploying to Netlify",
    content: "Today I completed the Daily Journal AI application and deployed it to Netlify. The writing prompts provide wonderful daily inspiration!",
    created_at: new Date().toISOString()
  },
  {
    id: 2,
    entry_date: new Date().toISOString().split("T")[0],
    mood: "Calm",
    topic: "Morning Reflection",
    title: "Quiet Coffee & Mindful Planning",
    content: "Took time this morning to enjoy a peaceful cup of tea, breathe deeply, and set clear intentions for the day.",
    created_at: new Date().toISOString()
  }
];

function init() {
  const saved = localStorage.getItem(STORAGE_KEY);
  if (saved) {
    try {
      entries = JSON.parse(saved);
    } catch (e) {
      entries = [...SEED_ENTRIES];
    }
  } else {
    entries = [...SEED_ENTRIES];
    saveToStorage();
  }

  // Set default date in filter
  const today = new Date().toISOString().split("T")[0];
  document.getElementById("dateFilterInput").value = today;

  render();
}

function saveToStorage() {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(entries));
}

function flash(message, category = "success") {
  const container = document.getElementById("flashContainer");
  const div = document.createElement("div");
  div.className = `flash-container`;
  div.innerHTML = `
    <div class="flash-message flash-${category}">
      <span>${escapeHtml(message)}</span>
      <button type="button" class="flash-close" onclick="this.parentElement.remove()">&times;</button>
    </div>
  `;
  container.innerHTML = "";
  container.appendChild(div);

  setTimeout(() => {
    if (div.parentElement) div.remove();
  }, 4000);
}

function escapeHtml(text) {
  const map = {
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#039;"
  };
  return text.replace(/[&<>"']/g, m => map[m]);
}

function render() {
  const grid = document.getElementById("entriesGrid");
  const emptyState = document.getElementById("emptyState");
  const filterStatus = document.getElementById("filterStatus");
  const filterStatusText = document.getElementById("filterStatusText");
  const clearSearchBtn = document.getElementById("clearSearchBtn");
  const clearDateBtn = document.getElementById("clearDateBtn");

  // Filter entries
  let filtered = [...entries];

  if (activeDateFilter) {
    filtered = filtered.filter(e => e.entry_date === activeDateFilter);
    clearDateBtn.style.display = "inline-flex";
  } else {
    clearDateBtn.style.display = "none";
  }

  if (activeSearch) {
    const q = activeSearch.toLowerCase();
    filtered = filtered.filter(e =>
      e.title.toLowerCase().includes(q) ||
      e.content.toLowerCase().includes(q) ||
      e.topic.toLowerCase().includes(q) ||
      e.mood.toLowerCase().includes(q)
    );
    clearSearchBtn.style.display = "inline-flex";
  } else {
    clearSearchBtn.style.display = "none";
  }

  // Filter status bar
  if (activeDateFilter && activeSearch) {
    filterStatus.style.display = "flex";
    filterStatusText.innerText = `Entries for ${activeDateFilter} matching “${activeSearch}”`;
  } else if (activeDateFilter) {
    filterStatus.style.display = "flex";
    filterStatusText.innerText = `Entries for ${activeDateFilter}`;
  } else if (activeSearch) {
    filterStatus.style.display = "flex";
    filterStatusText.innerText = `Search results for “${activeSearch}”`;
  } else {
    filterStatus.style.display = "none";
  }

  // Sort newest first
  filtered.sort((a, b) => {
    if (b.entry_date !== a.entry_date) {
      return b.entry_date.localeCompare(a.entry_date);
    }
    return (b.id || 0) - (a.id || 0);
  });

  if (filtered.length === 0) {
    grid.innerHTML = "";
    emptyState.style.display = "block";
    const msg = document.getElementById("emptyMessage");
    if (activeDateFilter) {
      msg.innerText = `There are no entries recorded on ${activeDateFilter}.`;
    } else if (activeSearch) {
      msg.innerText = `No entries match your search query "${activeSearch}".`;
    } else {
      msg.innerText = "Your journal is empty. Start by capturing your first daily reflection!";
    }
  } else {
    emptyState.style.display = "none";
    grid.innerHTML = filtered.map(e => `
      <article class="card">
        <div class="card-header">
          <span class="meta-date">📅 ${escapeHtml(e.entry_date)}</span>
          <span class="mood-badge mood-${escapeHtml(e.mood.toLowerCase())}">${escapeHtml(e.mood)}</span>
        </div>
        <div class="meta-topic">🏷️ ${escapeHtml(e.topic)}</div>
        <h2 class="card-title">${escapeHtml(e.title)}</h2>
        <p class="card-content">${escapeHtml(e.content)}</p>
        <div class="card-actions">
          <button type="button" class="button-edit" onclick="openEditEntryModal(${e.id})">✏️ Edit</button>
          <button type="button" class="danger" onclick="deleteEntry(${e.id})">🗑️ Delete</button>
        </div>
      </article>
    `).join("");
  }
}

// Search & Date filter
function handleSearch(val) {
  activeSearch = val.trim();
  render();
}

function clearSearch() {
  document.getElementById("searchInput").value = "";
  activeSearch = "";
  render();
}

function applyDateFilter() {
  const d = document.getElementById("dateFilterInput").value;
  if (d) {
    activeDateFilter = d;
    render();
  }
}

function clearDateFilter() {
  activeDateFilter = "";
  render();
}

function resetAllFilters() {
  clearSearch();
  clearDateFilter();
}

// Modal management
function openNewEntryModal() {
  document.getElementById("modalTitle").innerText = "Create Journal Entry";
  document.getElementById("entryId").value = "";
  document.getElementById("entryDate").value = new Date().toISOString().split("T")[0];
  document.getElementById("entryMood").value = "Calm";
  document.getElementById("entryTopic").value = "";
  document.getElementById("entryTitle").value = "";
  document.getElementById("entryContent").value = "";
  document.getElementById("promptBox").innerText = "Choose a mood and topic above, then click Generate AI Writing Prompt for inspiration.";
  document.getElementById("promptActions").style.display = "none";
  document.getElementById("saveSubmitBtn").innerText = "💾 Save Entry";
  document.getElementById("entryModal").style.display = "flex";
}

function openEditEntryModal(id) {
  const entry = entries.find(e => e.id === id);
  if (!entry) return;

  document.getElementById("modalTitle").innerText = "Edit Journal Entry";
  document.getElementById("entryId").value = entry.id;
  document.getElementById("entryDate").value = entry.entry_date;
  document.getElementById("entryMood").value = entry.mood;
  document.getElementById("entryTopic").value = entry.topic;
  document.getElementById("entryTitle").value = entry.title;
  document.getElementById("entryContent").value = entry.content;
  document.getElementById("promptBox").innerText = "Click to generate fresh ideas or reflective questions related to this entry.";
  document.getElementById("promptActions").style.display = "none";
  document.getElementById("saveSubmitBtn").innerText = "💾 Update Entry";
  document.getElementById("entryModal").style.display = "flex";
}

function closeModal() {
  document.getElementById("entryModal").style.display = "none";
}

// Prompt Generation
function generatePromptClient() {
  const mood = document.getElementById("entryMood").value;
  const topic = document.getElementById("entryTopic").value.trim() || "my day";
  const btnText = document.getElementById("btnText");
  const promptBox = document.getElementById("promptBox");
  const promptActions = document.getElementById("promptActions");

  btnText.innerText = "Generating prompt...";
  promptBox.innerHTML = "<em>✨ Thinking of a thoughtful reflection prompt for you...</em>";

  setTimeout(() => {
    const list = PROMPT_BANK[mood] || [];
    let promptTemplate = list[Math.floor(Math.random() * list.length)] || `Write about your thoughts and experiences today related to ${topic}.`;
    currentPrompt = promptTemplate.replace(/{topic}/g, topic);
    promptBox.innerText = currentPrompt;
    promptActions.style.display = "block";
    btnText.innerText = "Generate AI Writing Prompt";
  }, 250);
}

function usePromptClient() {
  if (!currentPrompt) return;
  const contentArea = document.getElementById("entryContent");
  if (contentArea.value.trim().length > 0) {
    contentArea.value = `Prompt: "${currentPrompt}"\n\n` + contentArea.value;
  } else {
    contentArea.value = `Prompt: "${currentPrompt}"\n\n`;
  }
  contentArea.focus();
  const promptActions = document.getElementById("promptActions");
  promptActions.innerHTML = "<span class='prompt-applied'>✅ Prompt added to your entry!</span>";
}

// Save (Create or Update)
function saveEntry(e) {
  e.preventDefault();
  const idStr = document.getElementById("entryId").value;
  const entry_date = document.getElementById("entryDate").value;
  const mood = document.getElementById("entryMood").value;
  const topic = document.getElementById("entryTopic").value.trim();
  const title = document.getElementById("entryTitle").value.trim();
  const content = document.getElementById("entryContent").value.trim();

  if (!entry_date || !mood || !topic || !title || !content) {
    alert("Please fill in all required fields.");
    return;
  }

  if (idStr) {
    // Update
    const id = parseInt(idStr, 10);
    const index = entries.findIndex(item => item.id === id);
    if (index !== -1) {
      entries[index] = {
        ...entries[index],
        entry_date,
        mood,
        topic,
        title,
        content,
        updated_at: new Date().toISOString()
      };
      saveToStorage();
      flash("Journal entry updated successfully!", "success");
    }
  } else {
    // Create
    const newEntry = {
      id: Date.now(),
      entry_date,
      mood,
      topic,
      title,
      content,
      created_at: new Date().toISOString()
    };
    entries.unshift(newEntry);
    saveToStorage();
    flash("Journal entry saved successfully!", "success");
  }

  closeModal();
  render();
}

// Delete
function deleteEntry(id) {
  if (!confirm("Are you sure you want to delete this journal entry?")) return;
  entries = entries.filter(e => e.id !== id);
  saveToStorage();
  flash("Journal entry deleted.", "info");
  render();
}

// Start
document.addEventListener("DOMContentLoaded", init);
